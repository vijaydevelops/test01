export const environment = {
  production: true,
  API_URL:"http://127.0.0.1:8000/",
  session_key:"",
};
