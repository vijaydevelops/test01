import { Component, OnInit } from '@angular/core';
import * as $ from "jquery";
import { Router } from '@angular/router';
import { environment } from '../../../environments/environment';
import { ServiceService } from '../service/service.service';
import { Storage } from '@ionic/storage';
import { CookieService  } from 'ngx-cookie-service';


@Component({
  selector: 'app-staffdetails',
  templateUrl: './staffdetails.page.html',
  styleUrls: ['./staffdetails.page.scss'],
})
export class StaffdetailsPage implements OnInit {

region_name=[];
branch_name=[];
received_branch_id="";
constructor(private cookies:CookieService,private storage:Storage,private api:ServiceService,private router: Router) { 
    
  try{
    var val={
      'action':'all'
    }

    this.api.call_api_post(environment.API_URL+"mastermodule/get_region_name_details",val).subscribe((result:any)=>{
          var res=result.data
          console.log(res)        
          this.region_name=res['data']
         

    })
   

        }catch(error){
          alert("please Enter The Number Correctly")
        }
    
 

}

  ngOnInit() {
  }

  std_reset()
  {
    $("#staff_name").val("");
    $("#branch_name").val("");
    $("#region_id").val("");
    $("#number").val("");
    $("#date").val("");
    $("#profession").val("");
    $("#age").val("");
    $("#email").val("");
    $("#exp").val("");
    $("#income").val("");
    
   
  }

  get_region_name($event) {
      
    console.log($event.target.value) ;
    var bran_val=$event.target.value;

    // this.received_branch_id=bran_val;

        try{
          var obj={
            "region_id":bran_val,
          }
      
          this.api.call_api_post(environment.API_URL+"mastermodule/get_branch_name_details",obj).subscribe((result:any)=>{
                var reg=result.data
                console.log(reg)        
                this.branch_name=reg['data']
               
      
          })
         
      
        }catch(error){
          alert("please Enter The Number Correctly")
        }



  }


  

  submit_staffdetails() 
  {

   
    if($("#staff_name").val()=="")
    {
      this.api.presentAlert("Please enter Staff details")
      setTimeout(function() {
        
        $("#staff_name").focus() 
      }, 2500);
    }
    // else if($("#branch_id").val()=="")
    // {
    //   this.api.presentAlert("Please enter Branch")
    //   setTimeout(function() {
    //     $("#branch_id").focus() 
    //   }, 2500);
    // }
    // else if($("region_id").val()=="")
    // {
    //   this.api.presentAlert("Please enter Region")
    //   setTimeout(function() {
    //     $("region_id").focus() 
    //   }, 2500);
    // }
    else if($("#number").val()=="")
    {
      this.api.presentAlert("Please enter Number")
      setTimeout(function() {
        $("#number").focus() 
      }, 2500);
    }
    else if($("#date").val()=="")
    {
      this.api.presentAlert("Please enter Date")
      setTimeout(function() {
        $("#date").focus() 
      }, 2500);
    }
    else if($("#profession").val()=="")
    {
      this.api.presentAlert("Please enter Profession")
      setTimeout(function() {
        $("#profession").focus() 
      }, 2500);
    }
    else if($("#age").val()=="")
    {
      this.api.presentAlert("Please enter Age")
      setTimeout(function() {
        $("#age").focus() 
      }, 2500);
    }
    else if($("#email").val()=="")
    {
      this.api.presentAlert("Please enter Email")
      setTimeout(function() {
        $("#email").focus() 
      }, 2500);
    }
    else if($("#exp").val()=="")
    {
      this.api.presentAlert("Please enter Experience")
      setTimeout(function() {
        $("#exp").focus() 
      }, 2500);
    }
    else if($("#income").val()=="")
    {
      this.api.presentAlert("Please enter valiable data")
      setTimeout(function() {
        $("#income").focus() 
      }, 2500);
    }
    
    else
    {
      //$("#s_password").hide()
      var b_id=this.received_branch_id;

      var obj1={
        
        "staff_name":$("staff_name").val(),
        "branch_id":b_id,
        "branch_name":$("branch_name").val(),
        "region_id":$("region_id").val(),
        "number":$("number").val(),
        "region_name":$("region_name").val(),
        "date":$("date").val(),
        "profession":$("profession").val(),
        "age":$("age").val(),
        "email":$("email").val(),
        "exp":$("exp").val(),
        "income":$("income").val(),
      }

      var res={}
      this.api.call_api_post(environment.API_URL+"mastermodule/save_region_master",obj1).subscribe((res:any)=>{
      var result=res.data
      console.log(result)

        if(result['message']=="ok")
        {  
        
          this.storage.create();
          
          // this.cookies.delete('session_key')
          this.storage.set('session_key',result['session_key']);
          this.cookies.set('session_key',result['session_key']);
        
          // var dt=result.data[0].user_type
          this.api.presentAlert("Registered successfuly")
          this.std_reset()
          
          // if(dt!="0")
          // {
          //   this.router.navigate(['/masters'])
          // }
          // else{
          //   this.router.navigate(['/usermodule'])
          // }
          
        
        }
      })
  
    }
  }


}
