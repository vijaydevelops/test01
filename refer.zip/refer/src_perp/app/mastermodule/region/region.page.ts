import { Component, OnInit } from '@angular/core';
import * as $ from "jquery";

import { Router } from '@angular/router';
import { environment } from '../../../environments/environment';
import { ServiceService } from '../service/service.service';
import { Storage } from '@ionic/storage';
import { CookieService  } from 'ngx-cookie-service';


@Component({
  selector: 'app-region',
  templateUrl: './region.page.html',
  styleUrls: ['./region.page.scss'],
})
export class RegionPage implements OnInit {

 branch_name=[];
 received_branch_id="";

  constructor(private cookies:CookieService,private storage:Storage,private api:ServiceService,private router: Router) { 
    
    // try{
    //   var val={
    //     'action':'all'
    //   }

    //   this.api.call_api_post(environment.API_URL+"mastermodule/get_branch_name_details",val).subscribe((result:any)=>{
    //         var res=result.data
    //         console.log(res)        
    //         this.branch_name=res['data']
           
  
    //   })
     

    //       }catch(error){
    //         alert("please Enter The Number Correctly")
    //       }
  }

  ngOnInit() {
  }

  reg_reset_form(){
    $("#region_name").val("")
    $("#region_des").val("")
    
  }

  // get_branch_id($event) {
      
  //   console.log($event.target.value) ;

  //   var bran_val=$event.target.value;

  //   this.received_branch_id=bran_val;
  // }

  

  submit_region() 
  {
    
    
    //var b_id=this.received_branch_id

    var obj={
     
      "region_name":$("#region_name").val(),
      "region_des":$("#region_des").val(),

    }
    console.log(obj);

    if(obj["region_name"]=="")
    {
      this.api.presentAlert("Please Enter region Name")
      setTimeout(function() {
        $("#region_name").focus() 
      }, 2500);
    }
    else if(obj["region_des"]=="")
    {
      this.api.presentAlert("Please write any Description")
      setTimeout(function() {
        $("#region_des").focus() 
      }, 2500);
    }
    else
    {
      //$("#s_password").hide()
      var res={}
      this.api.call_api_post(environment.API_URL+"mastermodule/save_region_master",obj).subscribe((res:any)=>{
      var result=res.data
      console.log(result)

        if(result['message']=="ok")
        {  
        
          this.storage.create();
          
          // this.cookies.delete('session_key')
          this.storage.set('session_key',result['session_key']);
          this.cookies.set('session_key',result['session_key']);
        
          // var dt=result.data[0].user_type
          this.api.presentAlert("Successfuly Submited")
          this.reg_reset_form()
          
          
          


          setTimeout(function() {
            this.region_reset_form()
           }, 1500);
          
          
          // if(dt!="0")
          // {
          //   this.router.navigate(['/masters'])
          // }
          // else{
          //   this.router.navigate(['/usermodule'])
          // }
          
        
        }
      })
  
    }
  }



}
