
import { Component, OnInit } from '@angular/core';
import * as $ from "jquery";
import { Router } from '@angular/router';
import { environment } from '../../../environments/environment';
import { CookieService  } from 'ngx-cookie-service';

import { Platform } from '@ionic/angular';
import { ServiceService } from '../service/service.service';
import { Storage } from '@ionic/storage';

@Component({
  selector: 'app-branch',
  templateUrl: './branch.page.html',
  styleUrls: ['./branch.page.scss'],
})
export class BranchPage implements OnInit {

  region_name=[];
  received_region_id="";
  constructor(private storage:Storage,private api:ServiceService,public platform: Platform,private router: Router,private cookies:CookieService) {

    
    try{
        var val={
          'action':'all'
        }
  
        this.api.call_api_post(environment.API_URL+"mastermodule/get_region_name_details",val).subscribe((result:any)=>{
              var res=result.data
              console.log(res)        
              this.region_name=res['data']
             
    
        })
       
  
            }catch(error){
              alert("please Enter The Number Correctly")
            }
   }

  ngOnInit() {
  }

  branch_reset_form(){
    $("#reg_id").val("")
    $("#branch_name").val("")
    $("#branch_des").val("")
  }



  get_region_id($event) {
      
      console.log($event.target.value) ;
  
      var reg_val=$event.target.value;
  
      this.received_region_id=reg_val;
    }
  


  // function for save branch detials

  submit_branch() 
  {
    var obj={
      "region_id": this.received_region_id,
      "branch_name":$("#branch_name").val(),
      "branch_des":$("#branch_des").val(),

    }
    console.log(obj);

    if(obj["region_id"]=="")
    {
      this.api.presentAlert("Please Enter Region Name")
      setTimeout(function() {
        $("#country").focus() 
      }, 2500);
    }

    else if(obj["branch_name"]=="")
    {
      this.api.presentAlert("Please Enter Branch Name")
      setTimeout(function() {
        $("#branch_name").focus() 
      }, 2500);
    }
    else if(obj["branch_des"]=="")
    {
      this.api.presentAlert("Please write any Description")
      setTimeout(function() {
        $("#branch_des").focus() 
      }, 2500);
    }
    else
    {
      //$("#s_password").hide()
      var res={}
      this.api.call_api_post(environment.API_URL+"mastermodule/save_branch_master",obj).subscribe((res:any)=>{
      var result=res.data
      console.log(result)

        if(result['message']=="ok")
        {  
        
          this.storage.create();
          
          // this.cookies.delete('session_key')
          this.storage.set('session_key',result['session_key']);
          this.cookies.set('session_key',result['session_key']);
        
          // var dt=result.data[0].user_type
          this.api.presentAlert("Submited successfuly")
          
          this.branch_reset_form()
        
          
          // if(dt!="0")
          // {
          //   this.router.navigate(['/masters'])
          // }
          // else{
          //   this.router.navigate(['/usermodule'])
          // }
          
        
        }
      })
  
    }
  }

}






