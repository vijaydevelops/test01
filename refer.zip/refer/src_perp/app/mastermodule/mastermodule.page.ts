import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-mastermodule',
  templateUrl: './mastermodule.page.html',
  styleUrls: ['./mastermodule.page.scss'],
})
export class MastermodulePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
