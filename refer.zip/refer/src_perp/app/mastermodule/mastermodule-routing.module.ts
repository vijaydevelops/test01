import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MastermodulePage } from './mastermodule.page';

const routes: Routes = [
  {
    path: '',
    component: MastermodulePage
  },
  {
    path: 'branch',
    loadChildren: () => import('./branch/branch.module').then( m => m.BranchPageModule)
  },
  {
    path: 'region',
    loadChildren: () => import('./region/region.module').then( m => m.RegionPageModule)
  },
  {
    path: 'staffdetails',
    loadChildren: () => import('./staffdetails/staffdetails.module').then( m => m.StaffdetailsPageModule)
  },
 
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MastermodulePageRoutingModule {}
