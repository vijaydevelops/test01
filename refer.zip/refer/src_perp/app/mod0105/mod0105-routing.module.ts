import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Mod0105Page } from './mod0105.page';

const routes: Routes = [
  {
    path: '',
    component: Mod0105Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Mod0105PageRoutingModule {}
