import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Mod0105PageRoutingModule } from './mod0105-routing.module';

import { Mod0105Page } from './mod0105.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Mod0105PageRoutingModule
  ],
  declarations: [Mod0105Page]
})
export class Mod0105PageModule {}
