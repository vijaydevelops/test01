import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mod0105',
  templateUrl: './mod0105.page.html',
  styleUrls: ['./mod0105.page.scss'],
})
export class Mod0105Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
