import { Component, OnInit,ViewChild} from '@angular/core';
import * as $ from "jquery";
import { IonModal } from '@ionic/angular';
import { OverlayEventDetail } from '@ionic/core/components';
import { AlertController } from '@ionic/angular';
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';
import { ServiceService } from '../mastermodule/service/service.service';
import { Storage } from '@ionic/storage';
import { CookieService  } from 'ngx-cookie-service';



@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {
  @ViewChild(IonModal) modal: IonModal;

  otp="";
  register_user_id="" ;

    constructor(private alertController: AlertController,private cookies:CookieService,private storage:Storage,private api:ServiceService,private router: Router) {}

  ngOnInit() {
  }

  message = 'This modal example uses triggers to automatically open a modal when the button is clicked.';
  name: string;

    cancel() {
      this.modal.dismiss(null, 'cancel');
    }

    confirm() {
      this.modal.dismiss(this.name, 'confirm');
    }

  // onWillDismiss(event: Event) {
   
  //   const ev = event as CustomEvent<OverlayEventDetail<string>>;
  //   if (ev.detail.role === 'confirm') {
  //     this.message = `Hello, ${ev.detail.data}!`;
  //   }
  // }


    reset_form(){

        $("#titleselect").val("")
        $("#name").val("")
        $("#fname").val("")
        $("#mname").val("")
        $("#genderselect").val("")
        $("#sname").val("")
        $("#email").val("")
        $("#date").val("")
        $("#mno").val("")
        $("#amno").val("")
        $("#company_name").val("")
        $("#password").val("")
        $("#c_password").val("")
        $("#address").val("")
        $("#city").val("")
        $("#state").val("")
        $("#pin").val("")
        $("#blood").val("")
        $("#ano").val("")
        $("#ac").val("")
        $("#pno").val("")
        $("#pc").val("")
    }


    // password checking

    // password_check(){

    //     var original_password=$("#password").val();
    //     var conifrm_password=$("#c_password").val();

        

    //     if(original_password != conifrm_password){

    //         this.api.presentAlert("Passsword Mismatch Please Check");
    //         setTimeout(function() {
    //           $("#name").focus()
    //         }, 1500);
    //     }


    // }



  register(){

   
    if($("#titleselect").val()=="")
    {
      this.api.presentAlert("Please Enter title")
        setTimeout(function() {
          $("#titleselect").focus()
          $('#titleselect').trigger('click');
        }, 2500);
      
    }
    else if($("#name").val()=="")
    {
      this.api.presentAlert("Please Enter name")
      setTimeout(function() {
        $("#name").focus()
       }, 1500);
    }
    else if($("#fname").val()=="")
    {
      this.api.presentAlert("Please Enter Father name")
      setTimeout(function() {
        $("#fname").focus()
       }, 1500);
    }
    else if($("#mname").val()=="")
    {
     
      this.api.presentAlert("Please Enter Mother name")
      setTimeout(function() {
        $("#mname").focus()
       }, 1500);
    }
    else if($("#genderselect").val()=="")
    {
      
      this.api.presentAlert("Please Enter Gender")
      setTimeout(function() {
        $("#genderselect").focus()
        $("#genderselect").trigger('click');
      }, 1500);
    }
    else if($("#sname").val()=="")
    {
      
      this.api.presentAlert("Please Enter spouse Name")
      setTimeout(function() {
        $("#sname").focus()
       }, 1500);
    }
    else if($("#email").val()=="")
    {
      $("#email").focus()
      this.api.presentAlert("Please Enter email")
      setTimeout(function() {
        $("#email").focus()
       }, 1500);
    }
    else if($("#date").val()=="")
    {
      
      this.api.presentAlert("Please Enter Date Of Birth")
      setTimeout(function() {
        $("#date").focus()
       }, 1500);
    }
    else if($("#mno").val()=="")
    {
      this.api.presentAlert("Please Enter Mobile Number")
      setTimeout(function() {
        $("#mno").focus()
       }, 1500);
    }
    else if($("#amno").val()=="")
    {
      this.api.presentAlert("Please Enter Alternative Mobile Number ")
      setTimeout(function() {
        $("#amno").focus()
       }, 1500);
    }
    else if($("#company_name").val()=="")
    {
      
      this.api.presentAlert("Please Enter Company Name")
      setTimeout(function() {
        $("#company_name").focus()
       }, 1500);
    }
    else if($("#password").val()=="")
    {
      this.api.presentAlert("Please Enter Password ")
      setTimeout(function() {
        $("#password").focus()
       }, 1500);
    }
    else if($("#c_password").val()=="")
    {
      
      this.api.presentAlert("Please Enter Confirm Password ")
      setTimeout(function() {
        $("#c_password").focus()
       }, 1500);
    }
    else if($("#password").val()!=$("#c_password").val()){

      this.api.presentAlert("Password Mismatch Please Check")
      setTimeout(function() {
        $("#c_password").focus()
        return
       }, 1500);
    }
    else if($("#address").val()=="")
    {
      
      this.api.presentAlert("Please Enter address")
      setTimeout(function() {
        $("#address").focus()
       }, 1500);
    }
    else if($("#city").val()=="")
    {
      
      this.api.presentAlert("Please Enter City")
      setTimeout(function() {
        $("#city").focus()
       }, 1500);
    }
    else if($("#state").val()=="")
    {
      
      this.api.presentAlert("Please Enter State")
      setTimeout(function() {
        $("#state").focus()
       }, 1500);
    }
    else if($("#pin").val()=="")
    {
      
      this.api.presentAlert("Please Enter Pin Number")
      setTimeout(function() {
        $("#pin").focus()
       }, 1500);
    }
    else if($("#blood").val()=="")
    {
      
      this.api.presentAlert("Please Enter Blood Group")
      setTimeout(function() {
        $("#blood").focus()
       }, 1500);
    }
    else if($("#ano").val()=="")
    {
      
      this.api.presentAlert("Please Enter Aathar card Number")
      setTimeout(function() {
        $("#ano").focus()
       }, 1500);
    }
    else if($("#ac").val()=="")
    {
      
      this.api.presentAlert("Please Enter Aathar Card Document")
      setTimeout(function() {
        $("#ac").focus()
       }, 1500);
    }
    else if($("#pno").val()=="")
    {
      
      this.api.presentAlert("Please Enter Pan Card Number")
      setTimeout(function() {
        $("#pno").focus()
       }, 1500);
    }
    else if($("#pc").val()=="")
    {
      
      this.api.presentAlert("Please Enter Pan Card Document")
      setTimeout(function() {
        $("#pc").focus()
       }, 1500);
    }
    else
    {
      var obj=
      {
        "title":$("#titleselect").val(),
        "name":$("#name").val(),
        "father_name":$("#fname").val(),
        "mother_name":$("#mname").val(),
        "gender":$("#genderselect").val(),
        "source_name":$("#sname").val(),
        "email":$("#email").val(),
        "birth_date":$("#date").val(),
        "mobile_number":$("#mno").val(),
        "alter_mobile_number":$("#amno").val(),
        "company_name":$("#company_name").val(),
        "password":$("#password").val(),
        "confirm_password":$("#c_password").val(),
        "address":$("#address").val(),
        "city":$("#city").val(),
        "state":$("#state").val(),
        "pincode":$("#pin").val(),
        "blood_grp":$("#blood").val(),
        "aadhar_no":$("#ano").val(),
        "aadhar_doc":$("#ac").val(),
        "pan_no":$("#pno").val(),
        "pan_doc":$("#pc").val(),
      }
      
      console.log('register',obj)
      
      var res={}
      this.api.call_api_post(environment.API_URL+"mastermodule/save_register_master",obj).subscribe((res:any)=>{
      var result=res.data

        console.log('result of save register',result);
      
        if(result['message']=="ok")
        {  


          this.register_user_id=result['data'][0].user_id;
            
        
          this.storage.create();
          this.storage.set('session_key',result['session_key']);
          this.cookies.set('session_key',result['session_key']);



            // get otp function


                var otp_num={
                  'mobile_number':$("#mobile_number").val(),
                };


                try{
                  this.api.call_api_post(environment.API_URL+"mastermodule/registration_otp",otp_num) .subscribe(res=>{
                      this.otp=res['message']
                      console.log(res)
                  });
                    
                }catch(error){

                  alert("please Enter The Number Correctly");

                }

            // get otp function end

            this.presentAlert()

            
           
        
        }
      })
  
    }

}


    async presentAlert() {

      const alert = await this.alertController.create({
        header: 'Please enter your OTP',
        buttons: [
          {
            text:'OK',
            handler: () => {
              var obj={
                  'user_id':this.register_user_id,
              }
              this.api.call_api_post(environment.API_URL+"mastermodule/save_register_master_active_flag",obj).subscribe((res:any)=>{
                var result=res.data
                if(result['message']=="ok")
                { 

                    this.api.presentAlert("Register Successfully")

                    let timeInMs = 3000;
                    let timeout= setTimeout( () => {
                      this.reset_form();
                      this.router.navigate(['/login'])
                    }, timeInMs );


                    
                }

              })
            }
          },
        ],
        inputs: [
          {
            placeholder: 'OTP',
            type: 'number',
            
          },
    
        ],
      });

      await alert.present();
    }



// check mobile number is already exist or not 

    check_no(){

        var obj={

          'mobile_no':$("#mno").val(),
        }


        var res_ok={}

        this.api.call_api_post(environment.API_URL+"mastermodule/check_mobile_no",obj).subscribe((res_ok:any)=>{
            var result=res_ok.data

              console.log(res_ok);

              var act=result.data;
              var temp_activate=act[0]['active'];

              if(result['dt_size']==1){


                if(temp_activate==0)
                {
                  this.api.presentAlert("Sorry Recheck Your Otp") 

                  let timeInMs = 3000;
                  let timeout= setTimeout( () => {
                    $("#name").val(act[0]['name'])
                    $("#fname").val(act[0]['father_name'])
                    $("#mname").val(act[0]['mother_name'])
                    $("#genderselect").val(act[0]['gender'])
                    $("#sname").val(act[0]['source_name'])
                    $("#email").val(act[0]['email'])
                    $("#date").val(act[0]['birth_date'])
                    $("#amno").val(act[0]['alter_mobile_number'])
                    $("#company_name").val(act[0]['company_name'])
                    $("#password").val(act[0]['password'])
                    $("#c_password").val(act[0]['confirm_password'])
                    $("#address").val(act[0]['address'])
                    $("#city").val(act[0]['city'])
                    $("#state").val(act[0]['state'])
                    $("#pin").val(act[0]['pincode'])
                    $("#blood").val(act[0]['blood_grp'])
                    $("#ano").val(act[0]['aadhar_no'])
                    $("#ac").val(act[0]['aadhar_doc'])
                    $("#pno").val(act[0]['pan_no'])
                    $("#pc").val(act[0]['pan_doc'])
                    
                  }, timeInMs );

                }
                else{

                  this.api.presentAlert("Your Number is Already exist Please login")

                  let timeInMs = 3000;
                  let timeout= setTimeout( () => {
                    this.router.navigate(['/login'])
                  }, timeInMs );

                }

                  
              }
        })

      }



    back(){

      this.router.navigate(['/login'])
    }


}
