import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Mod0103PageRoutingModule } from './mod0103-routing.module';

import { Mod0103Page } from './mod0103.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Mod0103PageRoutingModule
  ],
  declarations: [Mod0103Page]
})
export class Mod0103PageModule {}
