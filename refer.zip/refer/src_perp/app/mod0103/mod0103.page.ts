import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mod0103',
  templateUrl: './mod0103.page.html',
  styleUrls: ['./mod0103.page.scss'],
})
export class Mod0103Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
