import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Mod0103Page } from './mod0103.page';

const routes: Routes = [
  {
    path: '',
    component: Mod0103Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Mod0103PageRoutingModule {}
