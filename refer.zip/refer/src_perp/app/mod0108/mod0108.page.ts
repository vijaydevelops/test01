import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mod0108',
  templateUrl: './mod0108.page.html',
  styleUrls: ['./mod0108.page.scss'],
})
export class Mod0108Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
