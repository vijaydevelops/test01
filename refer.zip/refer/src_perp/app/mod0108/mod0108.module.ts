import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Mod0108PageRoutingModule } from './mod0108-routing.module';

import { Mod0108Page } from './mod0108.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Mod0108PageRoutingModule
  ],
  declarations: [Mod0108Page]
})
export class Mod0108PageModule {}
