import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SampleLoginPage } from './sample-login.page';

const routes: Routes = [
  {
    path: '',
    component: SampleLoginPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SampleLoginPageRoutingModule {}
