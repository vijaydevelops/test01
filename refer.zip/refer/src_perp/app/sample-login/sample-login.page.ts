import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sample-login',
  templateUrl: './sample-login.page.html',
  styleUrls: ['./sample-login.page.scss'],
})
export class SampleLoginPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
