import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mod0104',
  templateUrl: './mod0104.page.html',
  styleUrls: ['./mod0104.page.scss'],
})
export class Mod0104Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
