import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Mod0104Page } from './mod0104.page';

const routes: Routes = [
  {
    path: '',
    component: Mod0104Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Mod0104PageRoutingModule {}
