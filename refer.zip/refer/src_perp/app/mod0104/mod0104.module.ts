import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Mod0104PageRoutingModule } from './mod0104-routing.module';

import { Mod0104Page } from './mod0104.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Mod0104PageRoutingModule
  ],
  declarations: [Mod0104Page]
})
export class Mod0104PageModule {}
