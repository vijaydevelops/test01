import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Mod0102Page } from './mod0102.page';

const routes: Routes = [
  {
    path: '',
    component: Mod0102Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Mod0102PageRoutingModule {}
