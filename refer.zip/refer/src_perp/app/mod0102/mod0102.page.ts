import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mod0102',
  templateUrl: './mod0102.page.html',
  styleUrls: ['./mod0102.page.scss'],
})
export class Mod0102Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
