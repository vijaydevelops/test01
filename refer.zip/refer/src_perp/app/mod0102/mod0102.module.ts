import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Mod0102PageRoutingModule } from './mod0102-routing.module';

import { Mod0102Page } from './mod0102.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Mod0102PageRoutingModule
  ],
  declarations: [Mod0102Page]
})
export class Mod0102PageModule {}
