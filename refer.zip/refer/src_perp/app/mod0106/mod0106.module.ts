import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Mod0106PageRoutingModule } from './mod0106-routing.module';

import { Mod0106Page } from './mod0106.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Mod0106PageRoutingModule
  ],
  declarations: [Mod0106Page]
})
export class Mod0106PageModule {}
