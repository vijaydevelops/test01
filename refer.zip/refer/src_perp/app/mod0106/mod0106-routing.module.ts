import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Mod0106Page } from './mod0106.page';

const routes: Routes = [
  {
    path: '',
    component: Mod0106Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Mod0106PageRoutingModule {}
