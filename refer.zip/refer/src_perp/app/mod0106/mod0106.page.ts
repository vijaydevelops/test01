import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mod0106',
  templateUrl: './mod0106.page.html',
  styleUrls: ['./mod0106.page.scss'],
})
export class Mod0106Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
