import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { Mod0101PageRoutingModule } from './mod0101-routing.module';

import { Mod0101Page } from './mod0101.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    Mod0101PageRoutingModule
  ],
  declarations: [Mod0101Page]
})
export class Mod0101PageModule {}
