import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Mod0101Page } from './mod0101.page';

const routes: Routes = [
  {
    path: '',
    component: Mod0101Page
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class Mod0101PageRoutingModule {}
