import { Component, OnInit } from '@angular/core';  
import * as $ from "jquery";
import { Router } from '@angular/router';
import { environment } from '../../environments/environment';
import { CookieService  } from 'ngx-cookie-service';

import { Platform } from '@ionic/angular';
import { ServiceService } from '../mastermodule/service/service.service';
import { Storage } from '@ionic/storage';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.page.html',
  styleUrls: ['./forgotpassword.page.scss'],
})
export class ForgotpasswordPage implements OnInit {

  otp="";
  displayStyle = "none";

  constructor(private storage:Storage,private api:ServiceService,public platform: Platform,private router: Router,private cookies:CookieService) { 

   
   
  }

  ngOnInit() {

   

  }
  

  forgot_reset_form(){

      $("#number").val("");
      $("#otp").val("");
      $("#password").val("");
      $("#c_password").val("");
  }


  // send otp function using mobile number

    send_otp(){

        var obj={

            "mobile_number":$("#number").val(),
            "action":"password_check",
        }

        if(obj["mobile_number"]==""){

          this.api.presentAlert("Please Enter Mobile Number");
          return
        }else{

          try{
            this.api.call_api_post(environment.API_URL+"mastermodule/registration_otp",obj).subscribe(res=>{
  
                  var result=res.data
  
                  if(result['status']=="ok"){
  
                    $("#otp").focus();
                    this.otp=result['message'];
                     
                  }else if (result['status']=="not_ok"){
  
                    this.api.presentAlert("User Not Found Please Check Mobile Number")
  
                  }
                
            });
               
            
          }catch(error){
            this.api.presentAlert("Please Check No")
          }
        }

    
        if(this.otp=''){

          this.api.presentAlert("Please Check No ")

        }

    }


    // check otp no is right or wrong

    otp_enter(){

     
      
      if($("#otp").val()!=this.otp){
        
        this.api.presentAlert("OTP No MisMatch Please Check")

          let timeInMs = 2000;
          let timeout= setTimeout( () => {
            $("#otp").val("");
            $("#otp").show();
          }, timeInMs );

      }else{

        this.displayStyle="block"; 
      }
    }


    // change password function 

    change_password(){

      if(this.otp==''){
        this.api.presentAlert("Please Get OTP First")
        return;
      }

      var val={
        "mobile_number":$("#number").val(),
        "password":$("#password").val(),
        "cpassword":$("#c_password").val(),
      }

      if(val["password"]==""){
        this.api.presentAlert("Please Enter Your New Password");

        let timeInMs = 2000;
          let timeout= setTimeout( () => {
            $("#password").show();
          }, timeInMs );

      }else if(val["cpassword"]==""){

        this.api.presentAlert("Please Enter Your Confirm Password");

        let timeInMs = 2000;
          let timeout= setTimeout( () => {
            $("#c_password").show();
          }, timeInMs );

      }else if(val["password"] != val["cpassword"] ){

        this.api.presentAlert("Password Mismatch Please Check");

        let timeInMs = 2000;
        let timeout= setTimeout( () => {
          $("#c_password").show();
        }, timeInMs );

      }else{

          try{
            this.api.call_api_post(environment.API_URL+"mastermodule/change_password",val).subscribe(res=>{

              var result=res.data;
                    
              if(result['message']=="ok"){

                this.api.presentAlert("Password Change Successfully");

                let timeInMs = 2000;
                let timeout= setTimeout( () => {
                  this.router.navigate(['/login'])
                }, timeInMs );
                
              }

            })
    
          }catch(error){

            alert("Check The Connection...");

          }
      }

    }


}
