import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'register',
    loadChildren: () => import('./register/register.module').then( m => m.RegisterPageModule)
  },
  {
    path: 'master',
    loadChildren: () => import('./mastermodule/mastermodule.module').then( m => m.MastermodulePageModule)
  },
  {
    path: 'forgotpassword',
    loadChildren: () => import('./forgotpassword/forgotpassword.module').then( m => m.ForgotpasswordPageModule)
  },
  {
    path: 'sample-login',
    loadChildren: () => import('./sample-login/sample-login.module').then( m => m.SampleLoginPageModule)
  },
  {
    path: 'mod0101',
    loadChildren: () => import('./mod0101/mod0101.module').then( m => m.Mod0101PageModule)
  },
  {
    path: 'mod0102',
    loadChildren: () => import('./mod0102/mod0102.module').then( m => m.Mod0102PageModule)
  },
  {
    path: 'mod0103',
    loadChildren: () => import('./mod0103/mod0103.module').then( m => m.Mod0103PageModule)
  },
  {
    path: 'mod0104',
    loadChildren: () => import('./mod0104/mod0104.module').then( m => m.Mod0104PageModule)
  },
  {
    path: 'mod0105',
    loadChildren: () => import('./mod0105/mod0105.module').then( m => m.Mod0105PageModule)
  },
  {
    path: 'mod0106',
    loadChildren: () => import('./mod0106/mod0106.module').then( m => m.Mod0106PageModule)
  },
  {
    path: 'mod0107',
    loadChildren: () => import('./mod0107/mod0107.module').then( m => m.Mod0107PageModule)
  },
  {
    path: 'mod0108',
    loadChildren: () => import('./mod0108/mod0108.module').then( m => m.Mod0108PageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
