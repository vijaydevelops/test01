import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mod0107',
  templateUrl: './mod0107.page.html',
  styleUrls: ['./mod0107.page.scss'],
})
export class Mod0107Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
