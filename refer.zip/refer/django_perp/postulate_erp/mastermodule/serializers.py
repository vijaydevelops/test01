from rest_framework import serializers
from mastermodule.models import branch_master,region_master,enquiry




class register_save_details(serializers.ModelSerializer):
	class Meta:
		model=enquiry
		fields=('title','name','father_name','mother_name','gender','source_name','email','birth_date','mobile_number','alter_mobile_number','company_name','password','confirm_password','address','city','state','pincode','blood_grp','aadhar_no','aadhar_doc','pan_no','pan_doc','active','create_date','delflag','user_type')

class save_branch(serializers.ModelSerializer):
	class Meta:
		model=branch_master
		fields=('branch_name','branch_des','create_date','delflag','region_id')

class save_region(serializers.ModelSerializer):
	class Meta:
		model=region_master
		fields=('region_name','region_des','create_date','delflag')