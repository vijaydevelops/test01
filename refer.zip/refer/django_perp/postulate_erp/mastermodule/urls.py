from django.contrib import admin
from django.urls import path
from mastermodule import views
from django.urls import include
from django.conf import settings
from django.conf.urls.static import static
urlpatterns = [
    
     path('login',views.login,name="login"),
     path('save_branch_master',views.save_branch_master,name="save_branch_master"),
     path('get_branch_name_details',views.get_branch_name_details,name="get_branch_name_details"),
     path('check_mobile_no',views.check_mobile_no,name="check_mobile_no"),
     path('save_register_master',views.save_register_master,name="save_register_master"),
     path('get_region_name_details',views.get_region_name_details,name="get_region_name_details"),
     path('registration_otp',views.registration_otp,name="registration_otp"),
     path('save_register_master_active_flag',views.save_register_master_active_flag,name="save_register_master_active_flag"),
      path('change_password',views.change_password,name="change_password"),

]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)