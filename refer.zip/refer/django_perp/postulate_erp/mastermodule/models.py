from django.db import models
from datetime import datetime
from django.utils import timezone

# Create your models here.
class enquiry(models.Model):
	user_id=models.AutoField(primary_key=True)
	title=models.CharField(max_length=10,null=True)
	name=models.CharField(max_length=100)
	father_name=models.CharField(max_length=100)
	mother_name=models.CharField(max_length=100)
	gender=models.CharField(max_length=50)
	source_name=models.CharField(max_length=100)
	email =models.CharField(max_length=50)
	birth_date =models.DateField(null=True)
	mobile_number=models.CharField(max_length=50)
	alter_mobile_number=models.CharField(max_length=50)
	company_name =models.CharField(max_length=200,blank=True)
	password=models.CharField(max_length=50,blank=True)
	confirm_password=models.CharField(max_length=200,blank=True)
	address=models.CharField(max_length=700,blank=True)
	city=models.CharField(max_length=150,blank=True)
	state=models.CharField(max_length=200,blank=True)
	pincode=models.CharField(max_length=200,blank=True)
	blood_grp=models.CharField(max_length=150,blank=True)
	aadhar_no=models.CharField(max_length=50,blank=True)
	aadhar_doc=models.CharField(max_length=200,blank=True)
	pan_no=models.CharField(max_length=50,blank=True)
	pan_doc=models.CharField(max_length=200,blank=True)
	active=models.CharField(max_length=50,blank=True)
	create_date = models.DateTimeField(null=True)
	update_date = models.DateTimeField(null=True)
	delete_date = models.DateTimeField(null=True)
	delflag = models.CharField(max_length=3,default=0)
	user_type = models.CharField(max_length=3,default=0)
	class Meta:
		db_table='enquiry'


class region_master(models.Model):
	region_id=models.AutoField(primary_key=True)
	region_name=models.CharField(max_length=100)
	region_des=models.CharField(max_length=200)
	create_date = models.DateTimeField(null=True)
	update_date = models.DateTimeField(null=True)
	delete_date = models.DateTimeField(null=True)
	delflag = models.CharField(max_length=3,default=0)
	
	class Meta:
		db_table='region_master'

class branch_master(models.Model):
	branch_id=models.AutoField(primary_key=True)
	region_id =models.ForeignKey(region_master,db_column="region_id",on_delete=models.CASCADE,null=True)
	branch_name=models.CharField(max_length=100)
	branch_des=models.CharField(max_length=200)
	create_date = models.DateTimeField(null=True)
	update_date = models.DateTimeField(null=True)
	delete_date = models.DateTimeField(null=True)
	delflag = models.CharField(max_length=3,default=0)
	
	class Meta:
		db_table='branch_master'




