from django.shortcuts import render
import json
from django.views.decorators.csrf import csrf_exempt  #allow from other api's
from rest_framework.parsers import JSONParser
from django.http import JsonResponse
from django.forms.models import model_to_dict
from mastermodule.serializers import save_branch,save_region,register_save_details

from django.conf import settings
from django.core.mail import send_mail
import random
from django.utils import timezone
from django.contrib.sessions.models import Session
import datetime

from django.contrib.sessions.backends.db import SessionStore
from django.core.files.storage import default_storage

from mastermodule.models import enquiry,branch_master,region_master
from django.forms.models import model_to_dict
from django.core.files.base import ContentFile
# Create your views here.



@csrf_exempt
def check_mobile_no(request):
	if request.method=="POST":
		received_data=json.loads(request.body.decode('utf-8')) #json data
		data=enquiry.objects.filter(mobile_number=received_data['mobile_no']).values()
		dt=list(data)
		dt_size=len(dt)
		if dt_size>0:
			return  JsonResponse({"message":"ok",'data':dt,'dt_size':dt_size})
		else:
			return  JsonResponse({"message":"not_ok"})



@csrf_exempt
def get_branch_name_details(request):
	if request.method=="POST":
		received_data=json.loads(request.body.decode('utf-8')) #json data
		print(received_data)
		if received_data["branch_id"]!="":
			data=region_master.objects.filter(branch_id=received_data["branch_id"],delflag=0).values()
			dt=list(data)
			return  JsonResponse({"message":"ok",'data':dt})






@csrf_exempt
def login(request):
	if request.method=="POST":
		received_data=json.loads(request.body.decode('utf-8')) #json data
		data=enquiry.objects.filter(mobile_number=received_data['number'],password=received_data['password']).values()
		
		dt=list(data)
		
		if len(dt)>0:
			s = SessionStore()
			user_detail=dt[0]
			s['user_name']=user_detail['name']
			s['user_id']=user_detail['user_id']
			s.create()
			session_key=s.session_key
			return  JsonResponse({"message":"ok",'data':dt,'session_key':session_key})
		elif len(enquiry.objects.filter(mobile_number=received_data['number']))>0:
			return  JsonResponse({"message":"incorrect_password"})
		else:
			return  JsonResponse({"message":"not"})



@csrf_exempt
def save_branch_master(request):
	if request.method=="POST":
		received_data=json.loads(request.body.decode('utf-8')) #json data
		received_data['create_date']=timezone.now()
		received_data['del_flag']=0
		

		print(received_data)

		branch_save_serializer=save_branch(data=received_data)
		
		if branch_save_serializer.is_valid():
			branch_save_serializer.save()
			return  JsonResponse({"message":"ok"})
		else:
			print(branch_save_serializer.errors)
			return  JsonResponse({"message":"not_ok"})

@csrf_exempt
def get_region_name_details(request):
	if request.method=="POST":
		received_data=json.loads(request.body.decode('utf-8')) #json data
		#print(received_data)
		if received_data['action']=="all":
			data=region_master.objects.all().values()
			dt=list(data)
			return  JsonResponse({"message":"ok",'data':dt})



@csrf_exempt
def save_register_master(request):
	if request.method=="POST":
		received_data=json.loads(request.body.decode('utf-8')) #json data
		received_data['active']=0
		received_data['usertype']=0
		received_data['create_date']=timezone.now()
		received_data['del_flag']=0

		region_save_serializer=register_save_details(data=received_data)
		
		if region_save_serializer.is_valid():
			region_save_serializer.save()
			received_id=enquiry.objects.filter(mobile_number=received_data['mobile_number'],active=received_data['active']).values()
			rece_dt=list(received_id)
			return  JsonResponse({"message":"ok",'data':rece_dt})
		else:
			print(region_save_serializer.errors)
			return  JsonResponse({"message":"not_ok"})





# get otp function

@csrf_exempt
def registration_otp(request):
	if request.method=="POST":
		otp=random.randint(1000,9999)
		otp=1234
		received_data=json.loads(request.body.decode('utf-8')) #json data

		if "action" in received_data.keys():

			if(received_data['action']=="password_check"):
				
				data=enquiry.objects.filter(mobile_number=received_data['mobile_number']).values()
				dt=list(data)
				if len(dt)>0:
					dt=list(data)
					return  JsonResponse({"message":otp,'status':"ok"})
				else:
					return  JsonResponse({"message":otp,'status':"not_ok"})
		else:
			return  JsonResponse({"message":otp})




# after register click get otp to change active flag 

@csrf_exempt
def save_register_master_active_flag(request):
	if request.method=="POST":
		received_data=json.loads(request.body.decode('utf-8')) #json data

		prev_entry=enquiry.objects.get(user_id=received_data['user_id'])
		prev_entry.active=1
		prev_entry.save()
		return  JsonResponse({"message":"ok"})
		

# change password function 

@csrf_exempt
def change_password(request):
	if request.method=="POST":
		received_data=json.loads(request.body.decode('utf-8')) #json data
		data=enquiry.objects.get(mobile_number=received_data['mobile_number'])
		data.password=received_data['password']
		data.confirm_password=received_data['cpassword']
		data.save()
		return  JsonResponse({"message":"ok"})
